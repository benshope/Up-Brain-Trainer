// Display the native navigation bar with the title "Hello World!"
steroids.view.navigationBar.show("Hello World!");

// Set the WebView background color to white (effective on iOS only)
steroids.view.setBackgroundColor("#FFFFFF");
